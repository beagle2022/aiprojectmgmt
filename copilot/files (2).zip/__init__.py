"""
copilot package — self-healing path bootstrap
"""
import os
import sys

# Always ensure the directory that CONTAINS this 'copilot' folder is on sys.path.
# This works regardless of where Python is launched from.
_PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))   # .../ai_pm_copilot/copilot
_PROJECT_ROOT = os.path.dirname(_PACKAGE_DIR)               # .../ai_pm_copilot

if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from copilot.config import Config                # noqa: E402
from copilot.memory import MemoryManager         # noqa: E402
from copilot.orchestrator import Orchestrator    # noqa: E402
from copilot.agents import (                     # noqa: E402
    BaseAgent,
    RequirementsAgent,
    SprintPlannerAgent,
    RiskAnalystAgent,
    CodeReviewerAgent,
    StandupAgent,
    AGENT_REGISTRY,
)
from copilot.tools import ToolRegistry           # noqa: E402

__all__ = [
    "Config",
    "MemoryManager",
    "Orchestrator",
    "BaseAgent",
    "RequirementsAgent",
    "SprintPlannerAgent",
    "RiskAnalystAgent",
    "CodeReviewerAgent",
    "StandupAgent",
    "AGENT_REGISTRY",
    "ToolRegistry",
]
