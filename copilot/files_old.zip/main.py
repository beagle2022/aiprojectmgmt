"""
AI PM Copilot — Main entry point
Run: python main.py
"""

import asyncio
from copilot.orchestrator import Orchestrator
from copilot.memory import MemoryManager
from copilot.config import Config


async def main():
    config = Config()
    memory = MemoryManager(config)
    orchestrator = Orchestrator(config, memory)

    print("\n╔══════════════════════════════════════╗")
    print("║      AI Project Management Copilot   ║")
    print("╚══════════════════════════════════════╝")
    print("Type 'exit' to quit, 'memory' to inspect LTM.\n")

    while True:
        try:
            user_input = input("You › ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_input:
            continue
        if user_input.lower() == "exit":
            print("Goodbye.")
            break
        if user_input.lower() == "memory":
            memory.dump()
            continue

        response = await orchestrator.run(user_input)
        print(f"\nCopilot › {response}\n")


if __name__ == "__main__":
    asyncio.run(main())
