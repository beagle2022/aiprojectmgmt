"""
AI PM Copilot — Main entry point
Run: python main.py
"""

import asyncio
import os
import sys

# Ensure the project root is on sys.path regardless of where Python is invoked from
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from copilot.orchestrator import Orchestrator
from copilot.memory import MemoryManager
from copilot.config import Config


async def main():
    config = Config()
    missing = config.validate()
    if missing:
        print(f"[Error] Missing required environment variables: {', '.join(missing)}")
        print("Copy .env.example to .env and fill in the values, then retry.")
        sys.exit(1)

    memory = MemoryManager(config)
    orchestrator = Orchestrator(config, memory)

    print("\n╔══════════════════════════════════════╗")
    print("║      AI Project Management Copilot   ║")
    print("╚══════════════════════════════════════╝")
    print("Type 'exit' to quit, 'memory' to inspect LTM.\n")

    while True:
        try:
            user_input = input("You › ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_input:
            continue
        if user_input.lower() == "exit":
            print("Goodbye.")
            break
        if user_input.lower() == "memory":
            memory.dump()
            continue

        response = await orchestrator.run(user_input)
        print(f"\nCopilot › {response}\n")


if __name__ == "__main__":
    asyncio.run(main())
